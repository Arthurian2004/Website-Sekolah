<?php namespace App\Controllers;

class Page extends BaseController
{
	public function about()
	{
		$data['nhal']="About Me";
        echo view('header', $data);
		echo view('isiabout');
		echo view('footer');
	}
    
    public function satu()
	{
		$data['nhal']="Berita";
        echo view('header', $data);
		echo view('satu');
		echo view('footer');
	}
    
    public function dua()
	{
		$data['nhal']="Halaman Dua";
        echo view('header', $data);
		echo view('dua');
		echo view('footer');
	}

    public function tiga()
	{
		$data['nhal']="Halaman Dua";
        echo view('header', $data);
		echo view('tiga');
		echo view('footer');
	}

	public function sejarah()
	{
		$data['nhal']="Sejarah";
		echo view('sejarah');
		echo view('footer');
	}

	public function sambutan()
	{
		$data['nhal']="Sambutan Kepala Sekolah";
		echo view('sambutan');
		echo view('footer');
	}

	public function ppdb()
	{
		$data['nhal']="PPDB";
		echo view('ppdb');
		echo view('footer');
	}

	public function agama()
	{
		$data['nhal']="Program Keagamaan";
		echo view('agama');
		echo view('footer');
	}

	public function kurikulum()
	{
		$data['nhal']="Kurikulum Sekolah";
		echo view('kurikulum');
		echo view('footer');
	}

	public function guru()
	{
		$data['nhal']="Jajaran Guru-Guru";
		echo view('guru');
		echo view('footer');
	}

	public function ekstra()
	{
		$data['nhal']="Kegiatan Ekstrakulikuler";
		echo view('ekstra');
		echo view('footer');
	}

}