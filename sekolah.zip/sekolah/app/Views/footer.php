	<!-- Footer -->
	<footer class="text-light text-center text-lg-start" style="family-font:Montserrat; background-color: #273755;">
	<!-- Section: Social media -->
	<section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
		<!-- Left -->
		<div class="me-5 d-none d-lg-block">
		<span>Kunjungi media sosial kami:</span>
		</div>
		<!-- Left -->

		<!-- Right -->
		<div>
		<a href="https://www.facebook.com/" class="me-4 text-reset">
			<i class="fab fa-facebook-f"></i>
		</a>
		<a href="https://www.twitter.com/" class="me-4 text-reset">
			<i class="fab fa-twitter"></i>
		</a>
		<a href="https://www.instagram.com/" class="me-4 text-reset">
			<i class="fab fa-instagram"></i>
		</a>
		<a href="https://www.youtube.com/" class="me-4 text-reset">
			<i class="fab fa-youtube"></i>
		</a>
		</div>
		<!-- Right -->
	</section>
	<!-- Section: Social media -->

	<!-- Section: Links  -->
	<section class="">
		<div class="container text-center text-md-start mt-5">
		<!-- Grid row -->
		<div class="row mt-3">
			<!-- Grid column -->
			<div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
			<!-- Content -->
			<h6 class="text-uppercase fw-bold mb-4" style="font-family:Montserrat">
				<i class="fas fa-gem me-3"></i>SMP Islam Percobaan
			</h6>
			<p>
				SMP Islam Percobaan adalah sebuah SMP Unggulan yang berbasis Islam yang berlokasi di Kota Malang
			</p>
			</div>
			<!-- Grid column -->

			<!-- Grid column -->
			<div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
			<!-- Links -->
			<h6 class="text-uppercase fw-bold mb-4">
				Aplikasi Sekolah
			</h6>
			<p>
				<a href="#!" class="text-reset">SSPDB (Sistem Seleksi Peserta Didik baru)</a>
			</p>
			<p>
				<a href="#!" class="text-reset">Perpustakan Online</a>
			</p>
			<p>
				<a href="#!" class="text-reset">E-Class</a>
			</p>
			<p>
				<a href="#!" class="text-reset">Pembayaran Online</a>
			</p>
			</div>
			<!-- Grid column -->

			<!-- Grid column -->
			<div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
			<!-- Links -->
			<h6 class="text-uppercase fw-bold mb-4" style="font-family:Montserrat">
				LINK TERKAIT
			</h6>
			<p>
				<a href="https://kemenag.go.id/" class="text-reset">Kementerian Agama RI</a>
			</p>
			<p>
				<a href="https://jatim.kemenag.go.id/" class="text-reset">Kementerian Agama Jawa Timur</a>
			</p>
			<p>
				<a href="https://www.kemdikbud.go.id/main/" class="text-reset">Kemdikbud RI</a>
			</p>
			<p>
				<a href="https://dindik.jatimprov.go.id/" class="text-reset">Kemdikbud Jawa Timur</a>
			</p>
			</div>
			<!-- Grid column -->

			<!-- Grid column -->
			<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
			<!-- Links -->
			<h6 class="text-uppercase fw-bold mb-4">
				Contact
			</h6>
			<p><i class="fas fa-home me-3"></i> Malang, Jawa Timur, Indonesia</p>
			<p>
				<i class="fas fa-envelope me-3"></i>
				kelompokpdwhahahihi@mail.com
			</p>
			<p><i class="fas fa-phone me-3"></i> + 62 859 4047 4523</p>
			</div>
			<!-- Grid column -->
		</div>
		<!-- Grid row -->
		</div>
	</section>
	<!-- Section: Links  -->

	<!-- Copyright -->
	<div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
		Website ini dibuat oleh Kelompok G PDW 2022
	</div>
	<!-- Copyright -->
	</footer>
	<!-- Footer -->	

	<!-- Jquery dan Bootsrap JS -->
	<script src="<?= base_url('js/jquery.min.js') ?>"></script>
	<script src="<?= base_url('js/bootstrap.min.js') ?>"></script>