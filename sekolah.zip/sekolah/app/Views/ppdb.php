<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Website SMP Islam Percobaan</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,300,700' rel='stylesheet' type='text/css'>
	<script src="https://kit.fontawesome.com/b5bf755f1d.js" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
</head>	

    <div class="header py-4" style="background-color: #273755;">
		<div class="container">
			<a href="https://www.facebook.com/" class="fa fa-facebook" style="color: #FFFFFF;"></a>
			<a href="https://www.twitter.com/" class="px-4 fa fa-twitter" style="color: #1D9BF0;"></a>
			<a href="https://www.instagram.com/" class="fa fa-instagram" style="color: #8A3AB9;"></a>
			<a href="https://www.youtube.com/" class="px-4 fa fa-youtube" style="color: #FF0000;"></a>
		</div>
	</div>

	<nav class="navbar navbar-expand-sm sticky-top py-4 navbar-dark" style="background-color: #8AABCA; font-family:Montserrat;" id="mainNav;">
		<div class="container">
			<h2>
				<a class="navbar-brand" href="<?= base_url() ?>">
					<img src="https://iili.io/X4hfwb.png" height="30">
					SMP Islam Percobaan
				</a>
			</h2>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      			<span class="navbar-toggler-icon"></span>
    		</button>
			<div class="collapse navbar-collapse" style="color: #273755;" id="navbarNav">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url() ?>">Beranda</a>
					</li>
					<li class="nav-item dropdown">
          				<a class="nav-link dropdown-toggle" aria-current="page" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            				Profil Sekolah
          				</a>
          				<ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink" style="background-color:#273755;">
						  	<li><a class="dropdown-item" href="sejarah">Sejarah Sekolah</a></li>
						 	<li><a class="dropdown-item" href="sambutan">Sambutan Kepala Sekolah</a></li>
							<li><a class="dropdown-item" href="guru">Jajaran Guru-Guru</a></li>
          				</ul>
					</li>
					<li class="nav-item dropdown">
          				<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            				Program Sekolah
          				</a>
          				<ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink" style="background-color:#273755;">
            				<li><a class="dropdown-item" href="kurikulum">Kurikulum Sekolah</a></li>
            				<li><a class="dropdown-item" href="agama">Program Keagamaan</a></li>
							<li><a class="dropdown-item" href="ekstra">Kegiatan Ekstrakulikuler</a></li>
          				</ul>
					</li>
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" style="color: #273755;" href="<?= base_url('ppdb') ?>">PPDB</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

    <header class="jumbotron jumbotron-fluid">
		<div class="container">
			<div class="row">
				<div class="col-md-12 py-4" style="font-family:Montserrat;">
					<h1 class="h1">FORM PPDB</h1>
                    <br>
				</div>
			</div>
		</div>
	</header>

    <div class="container">
			<div class="row">
				<div class="col-md-12" style="font-family:Montserrat;">
					<h2 class="h2">Biodata Siswa</h1>
                    <br>
				</div>
			</div>
		</div>
    </div>

    <div class="container">
        <form class="row g-2 needs-validation" novalidate>
            <div class="col-md-6 mb-3">
                <label for="input-group-text" class="form-label">Nama Lengkap</label>
                <input type="text" class="form-control">
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                <label class="form-check-label" for="exampleRadios1">
                    Laki-laki
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
                <label class="form-check-label" for="exampleRadios2">
                    Perempuan
                </label>
            </div>
        </form>
        <form class="row g-2">
            <div class="col-md-4 mb-3">
                <label for="input-group-text" class="form-label">Tempat Lahir</label>
                <input type="text" class="form-control">
            </div>
            <div class="col-md-2 mb-3 form-group py-2"> <!-- Date input -->
                <label class="control-label" for="date">Tanggal Lahir</label>
                <input class="form-control" id="date" name="date" placeholder="MM/DD/YYY" type="text"/>
            </div>
            <br>
        </form>
        <form>
            <div class="col-md-6 mb-3">
                <label for="input-group-text" class="form-label">Alamat Lengkap</label>
                <input type="text" class="form-control" style="height: 100px">
            </div>
            <div class="col-md-6 input-group mb-3">
                <input type="file" class="form-control" id="inputGroupFile02">
                <label class="input-group-text" for="inputGroupFile02">Upload</label>
            </div>
        </form>
    </div>
    <br><br>
    
    <div class="container">
			<div class="row">
				<div class="col-md-12" style="font-family:Montserrat;">
					<h2 class="h2">Data Tambahan</h1>
                    <br>
				</div>
			</div>
		</div>
    </div>

    <div class="container">
        <form class="row g-3">
            <div class="col-md-3 mb-3">
                <label for="input-group-text" class="form-label">Nomor KK atau NIK Ortu/Wali</label>
                <input type="text" class="form-control">
            </div>
            <div class="col-md-3 mb-3">
                <label for="input-group-text" class="form-label">Nomor Akta Kelahiran</label>
                <input type="text" class="form-control">
            </div>
            <div class="col-md-3 mb-3">
                <label for="input-group-text" class="form-label">Nomor Induk Siswa Nasional</label>
                <input type="text" class="form-control">
            </div>
        <form>
    </div>
    
    <div class="container">
        <form class="row g-3">
            <div class="col-md-3 mb-3">
                <label for="input-group-text" class="form-label">Status Domisili</label>
                <input type="text" class="form-control">
            </div>
            <div class="col-md-3 mb-3">
                <label for="input-group-text" class="form-label">Nomor HP Ortu/Wali</label>
                <input type="text" class="form-control">
            </div>
        <form>
    </div>

    <div class="container">
        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Centang jika telah selesai</label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
            

<br><br><br>

<script>
    $(document).ready(function(){
      var date_input=$('input[name="date"]'); //our date input has the name "date"
      var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
      var options={
        format: 'mm/dd/yyyy',
        container: container,
        todayHighlight: true,
        autoclose: true,
      };
      date_input.datepicker(options);
    })
</script>

