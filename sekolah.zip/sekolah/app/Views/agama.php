<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SMP Islam Percobaan</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,300,700' rel='stylesheet' type='text/css'>
	<script src="https://kit.fontawesome.com/b5bf755f1d.js" crossorigin="anonymous"></script>
</head>

<body id="page-top">
	<div class="header py-4" style="background-color: #273755;">
		<div class="container">
			<a href="https://www.facebook.com/" class="fa fa-facebook" style="color: #FFFFFF; position"></a>
			<a href="https://www.twitter.com/" class="px-4 fa fa-twitter" style="color: #1D9BF0;"></a>
			<a href="https://www.instagram.com/" class="fa fa-instagram" style="color: #8A3AB9;"></a>
			<a href="https://www.youtube.com/" class="px-4 fa fa-youtube" style="color: #FF0000;"></a>
		</div>
	</div>
	<nav class="navbar navbar-expand-sm sticky-top py-4 navbar-dark" style="background-color: #8AABCA; font-family:Montserrat;" id="mainNav;">
		<div class="container">
			<h2>
				<a class="navbar-brand" href="<?= base_url() ?>">
					<img src="https://iili.io/X4hfwb.png" height="30">
					SMP Islam Percobaan
				</a>
			</h2>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      			<span class="navbar-toggler-icon"></span>
    		</button>
			<div class="collapse navbar-collapse active" aria-current="page" style="color: #273755;" id="navbarNav">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url() ?>">Beranda</a>
					</li>
					<li class="nav-item dropdown">
          				<a class="nav-link dropdown-toggle" aria-current="page" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            				Profil Sekolah
          				</a>
          				<ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink" style="background-color:#273755;">
						  	<li><a class="dropdown-item" href="sejarah">Sejarah Sekolah</a></li>
						 	<li><a class="dropdown-item" href="sambutan">Sambutan Kepala Sekolah</a></li>
							<li><a class="dropdown-item" href="guru">Jajaran Guru-Guru</a></li>
          				</ul>
					</li>
					<li class="nav-item dropdown">
          				<a class="nav-link dropdown-toggle active" aria-current="page" style="color: #273755;" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            				Program Sekolah
          				</a>
          				<ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink" style="background-color:#273755;">
            				<li><a class="dropdown-item" href="kurikulum">Kurikulum Sekolah</a></li>
            				<li><a class="dropdown-item" href="agama">Program Keagamaan</a></li>
							<li><a class="dropdown-item" href="ekstra">Kegiatan Ekstrakulikuler</a></li>
          				</ul>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url('ppdb') ?>">PPDB</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

    <br><br>
    <header class="jumbotron jumbotron-fluid">
		<div class="container">
			<div class="row">
				<div class="col-md-12 py-4" style="font-family:Montserrat;">
					<h1 class="h1">Program Keagamaan</h1>
                    <br><br>
				</div>
			</div>
		</div>
	</header>

    <div class="container" style="font-family:Montserrat;">
        <h3>Program Tahfidz Al-Qur'an</h3>
        <br>
        <img src="https://cdn-2.tstatic.net/tribunnews/foto/bank/images/nusantara-mengaji-nih2_20170419_105631.jpg" class="d-block w-100">
	</div>
    <br>
    <div class="container" style="font-family:Montserrat;">
        Program Tahfidz adalah program menghafal Al-Qur’an yang memungkinkan pembentukan keterampilan, pengetahuan, dan sikap secara maksimal dalam menghafal AlQur’an. Program Tahfidz, diharapkan terbentuknya pengetahuan, keterampilan, dan sikap dalam menghafal Al-Qur’an yang dibutuhkan melalui tatap muka. Program Tahfidz bertujuan mengembangkan jati diri peserta didik sesuai kemampuan dalam menghafal Al-Qur’an serta menerapkannya dalam dalam kehidupan masyarakat. Salah satu tujuan hafal adalah untuk ikut menjaga keaslian Al-Quran dan mempermudah belajar syariah Islam dari sumbernya yang asli di samping As-Sunnah.
	</div>
    <br><br>

    <div class="container" style="font-family:Montserrat;">
        <h3>Pondok Pesantren</h3>
        <br>
        <img src="https://assets.promediateknologi.com/crop/0x0:0x0/x/photo/2021/06/15/2624627405.jpg" class="d-block w-100">
	</div>
    <br>
    <div class="container" style="font-family:Montserrat;">
        Untuk memperkuat pemahaman dasar-dasar keagamaan islam dan kemampuan berbahasa asing, SMP Islam Percobaan menyediakan fasilitas berupa pondok pesantren. Dalam asrama ini terdapat Kyai sebagai pengasuh utama, ustadz/ah sebagai pengasuh harian, serta musyrif/ah yang mendapingi tiap-tiap kamar.
	</div>
    <br><br>

</body>

