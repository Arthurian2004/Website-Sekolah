
	<nav class="navbar navbar-expand-md py-5 navbar-dark" style="background-color: #000080;">
		<div class="container">
				<ul class="navbar-nav">
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url() ?>">Beranda</a>
					</li>
                </ul>
                <a class="navbar-brand px-4" href="<?= base_url('about') ?>">About Me</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('satu') ?>">Satu</a>
                        </li>
                        <li class="nav-item px-4">
                            <a class="nav-link" href="<?= base_url('dua') ?>">Dua</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?= base_url('tiga') ?>">Tiga</a>
                        </li>
                    </ul>
                </div>
		</div>
	</nav>

<!-- batas awal (isi).php -->
	<header class="jumbotron jumbotron-fluid">
		<div class="container">
			<div class="row">
				<div class="col-md-12 py-4">
					<h1 class="display-3 fw-bold fst-italic text-center">About Me</h1>
				</div>
			</div>
		</div>
	</header>

	<div class="container py-5">
        <div class="clearfix">
            <h>
                <title>Biodata Diri</title>
            </h>
                <body>
                    <p>Nama                 : Rizky Syirajuddin <img src="https://iili.io/04Kewb.md.jpg" style="float:right;width:384px;height:216px;"></p>
                    <p>NIM                  : 19190054</p>
                    <p>Program Studi        : Tadris Matematika</p>
                    <p>email                : rizkysyirajuddin@gmail.com</p>
                    <p>Alamat               : Gempol, Pasuruan</p>
                    <p>Hobi                 : Membaca, Bermain dengan hewan, Game</p>
                    <p>Organisasi           : Koordinator Divisi Media dan Informasi HMJ Tadris Matematika</p>
                </body>
        </div>
    </div>
<!-- batas akhir isi.php -->
