<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SMP Islam Percobaan</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,300,700' rel='stylesheet' type='text/css'>
	<script src="https://kit.fontawesome.com/b5bf755f1d.js" crossorigin="anonymous"></script>
</head>

<body id="page-top">
	<div class="header py-4" style="background-color: #273755;">
		<div class="container">
			<a href="https://www.facebook.com/" class="fa fa-facebook" style="color: #FFFFFF; position"></a>
			<a href="https://www.twitter.com/" class="px-4 fa fa-twitter" style="color: #1D9BF0;"></a>
			<a href="https://www.instagram.com/" class="fa fa-instagram" style="color: #8A3AB9;"></a>
			<a href="https://www.youtube.com/" class="px-4 fa fa-youtube" style="color: #FF0000;"></a>
		</div>
	</div>
	<nav class="navbar navbar-expand-sm sticky-top py-4 navbar-dark" style="background-color: #8AABCA; font-family:Montserrat;" id="mainNav;">
		<div class="container">
			<h2>
				<a class="navbar-brand" href="#page-top">
					<img src="https://iili.io/X4hfwb.png" height="30">
					SMP Islam Percobaan
				</a>
			</h2>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      			<span class="navbar-toggler-icon"></span>
    		</button>
			<div class="collapse navbar-collapse active" aria-current="page" style="color: #273755;" id="navbarNav">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" style="color: #273755;" href="<?= base_url() ?>">Beranda</a>
					</li>
					<li class="nav-item dropdown">
          				<a class="nav-link dropdown-toggle" aria-current="page" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            				Profil Sekolah
          				</a>
          				<ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink" style="background-color:#273755;">
						  	<li><a class="dropdown-item" href="sejarah">Sejarah Sekolah</a></li>
						 	<li><a class="dropdown-item" href="sambutan">Sambutan Kepala Sekolah</a></li>
							<li><a class="dropdown-item" href="guru">Jajaran Guru-Guru</a></li>
          				</ul>
					</li>
					<li class="nav-item dropdown">
          				<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            				Program Sekolah
          				</a>
          				<ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink" style="background-color:#273755;">
            				<li><a class="dropdown-item" href="kurikulum">Kurikulum Sekolah</a></li>
            				<li><a class="dropdown-item" href="agama">Program Keagamaan</a></li>
							<li><a class="dropdown-item" href="ekstra">Kegiatan Ekstrakulikuler</a></li>
          				</ul>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url('ppdb') ?>">PPDB</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

  	<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
  		<div class="carousel-indicators">
    		<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    		<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    		<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  		</div>
  		<div class="carousel-inner">
    		<div class="carousel-item active" data-bs-interval="5000">
      			<img src="https://iili.io/XeCJzg.jpg" class="d-block w-100">
    		</div>
    		<div class="carousel-item" data-bs-interval="5000">
      			<img src="https://iili.io/XeC9mF.jpg" class="d-block w-100">
    		</div>
    		<div class="carousel-item" data-bs-interval="5000">
      			<img src="https://iili.io/XeBye1.jpg" class="d-block w-100">
    		</div>
  		</div>
  		<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
    		<span class="visually-hidden">Previous</span>
  		</button>
  		<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    		<span class="carousel-control-next-icon" aria-hidden="true"></span>
    		<span class="visually-hidden">Next</span>
  		</button>
	</div>

	<br><br><br>

	<figure class="text-center fw-bold" style="font-family:Montserrat; color: #273755;">
  		<blockquote class="blockquote">
    		<h1>To educate a man in mind and not in morals is to educate a menace to society.</h1>
  		</blockquote>
		<br>
  		<figcaption class="blockquote-footer">
    		Theodore Roosevelt
  		</figcaption>
	</figure>
	<br><br><br>

	<div class="container">
		<h2 class="text-center fw-bold" style="font-family:Montserrat; color: #273755;">
			PROFIL SMP ISLAM PERCOBAAN
		</h2>
		<br>
		<hr/>
		<div class="row">
			<div class="col">
				<h4 class="text-center" style="font-family:Montserrat">
				<br>
				SMP ISLAM PERCOBAAN adalah salah satu satuan pendidikan dengan jenjang SMP di Kec. Lowokwaru, Kota Malang, Jawa Timur. SMP Islam Percobaan juga merupakan sekolah yang terbaik di Kota Malang, dan salah satu sekolah Kejuruan dan sudah bergabung dengan PRODISTIK. Dalam menjalankan kegiatannya, SMP ISLAM PERCOBAAN berada di bawah naungan Kementerian Pendidikan dan Kebudayaan. SMP ISLAM PERCOBAAN beralamat di Jalan RA Kartini, Kec. Lowokwaru, Kota Malang, Jawa Timur. SMP ISLAM PERCOBAAN memiliki akreditasi A, berdasarkan sertifikat 104/BOP-S/M/SK/XI/2017.
				</h4>
				<br>
			</div>
		</div>
		<hr/>
	</div>

	<br><br><br>

	<div class="container">
		<h2 class="text-center fw-bold" style="font-family:Montserrat; color: #273755;">
			SEKILAS SMP ISLAM PERCOBAAN
		</h2>
		<br>
		<hr/><br>
		<div class="row align-items">
			<div class="col">
				<h4 class="text-center" style="font-family:Montserrat">
					<i class="fa-solid fa-chalkboard-user fa-3x" style="color: #273755;"></i>
					<br><br>
					1500 Peserta Didik
				</h4>
			</div>
			<div class="col">
				<h4 class="text-center" style="font-family:Montserrat">
					<i class="fa-solid fa-person-chalkboard fa-3x" style="color: #273755;"></i>
						<br><br>
						100 Tenaga Pendidik
				</h4>
			</div>
			<div class="col">
				<h4 class="text-center" style="font-family:Montserrat">
					<i class="fa-solid fa-people-group fa-3x" style="color: #273755;"></i>
						<br><br>
						7000 Alumni
				</h4>
			</div>
			<div class="col">
				<h4 class="text-center" style="font-family:Montserrat">
						<i class="fa-solid fa-graduation-cap fa-3x" style="color: #273755;"></i>
						<br><br>
						500+ Prestasi
				</h4>
			</div>
		</div>
		<hr/>
		<br><br><br>
		<div class="container">
			<h2 class="text-center fw-bold" style="font-family:Montserrat; color: #273755;">
				VISI SEKOLAH
			</h2>
			<br>
			<hr/><br>
			<div class="row align-items">
				<div class="col">
					<h4 class="text-center" style="font-family:Montserrat">
						“BERPRESTASI DAN BERBUDAYA LINGKUNGAN YANG BERLANDASKAN IMTAQ DAN IPTEKS.”
					</h4>
					<br><hr/>
				</div>
			</div>
		</div>
		<br><br><br>
		<div class="container">
			<h2 class="text-center fw-bold" style="font-family:Montserrat; color: #273755;">
				MISI SEKOLAH
			</h2>
			<br>
			<hr/><br>
			<div class="row align-items">
				<div class="col">
					<h4 class="text-center" style="font-family:Montserrat">
						<i class="fa-solid fa-1 fa-2x" style="color: #273755;"></i>
						<br><br>
						Mewujudkan penghayatan dan pengamalan terhadap ajaran agama yang dianut warga sekolah.
					</h4>
				</div>
				<div class="col">
					<h4 class="text-center" style="font-family:Montserrat">
						<i class="fa-solid fa-2 fa-2x" style="color: #273755;"></i>
						<br><br>
						Mewujudkan komitmen dan loyalitas yang tinggi bagi seluruh warga sekolah terhadap tugas pokok dan fungsinya.
					</h4>
				</div>
			</div>
			<br><br>
			<div class="row align-items">
				<div class="col">
					<h4 class="text-center" style="font-family:Montserrat">
						<i class="fa-solid fa-3 fa-2x" style="color: #273755;"></i>
						<br><br>
						Melaksanakan pendidikan, pembelajaran, dan pembimbingan secara kreatif, inovatif, aktual.
					</h4>
				</div>
				<div class="col">
					<h4 class="text-center" style="font-family:Montserrat">
						<i class="fa-solid fa-4 fa-2x" style="color: #273755;"></i>
						<br><br>
						Mewujudkan semangat keunggulan, kekreativitasan, keinovasian dan kemandirian kepada seluruh warga sekolah dalam melaksanakan tugas.
					</h4>
				</div>
			</div>
			<br><br>
			<div class="row align-items">
				<div class="col">
					<h4 class="text-center" style="font-family:Montserrat">
						<i class="fa-solid fa-5 fa-2x" style="color: #273755;"></i>
						<br><br>
						Mewujudkan manajemen berbasis sekolah yang transparan, demokratis, partisipatif, dan akuntabel yang efektif dan efisien serta mengutamakan kepuasan masyarakat.
					</h4>
				</div>
				<div class="col">
					<h4 class="text-center" style="font-family:Montserrat">
						<i class="fa-solid fa-6 fa-2x" style="color: #273755;"></i>
						<br><br>
						Membangun jiwa semangat nasionalisme dan kebangsaan dalam keutuhan NKRI.
					</h4>
				</div>
			</div>
		</div>
		<br><hr/>

		<br><br><br><br>
		<h2 class="text-center fw-bold" style="font-family:Montserrat; color: #273755;">
			GALERI SEKOLAH
		</h2>
		<br>
		<hr/>
		<br>
		<div class="row align-items">
			<div class="col">
				<img src="https://iili.io/XU2bwX.md.jpg" class="d-block w-100">
			</div>
			<div class="col">
				<img src="https://iili.io/XU2Dut.jpg" class="d-block w-100">
			</div>
		</div>
		<br>
		<div class="row align-items">
			<div class="col">
				<img src="https://iili.io/XU2Q8N.jpg" class="d-block w-100">
			</div>
			<div class="col">
				<img src="https://iili.io/XU2Lap.jpg" class="d-block w-100">
			</div>
		</div>
		<br>
		<hr/>
	</div>
	<br><br><br><br><br><br><br>
	
	<!-- Footer -->
	<footer class="text-light text-center text-lg-start container-fluid" style="family-font:Montserrat; background-color: #273755; ">
		<!-- Section: Social media -->
		<section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
			<!-- Left -->
			<div class="me-5 d-none d-lg-block">
			<span>Kunjungi media sosial kami:</span>
			</div>
			<!-- Left -->

			<!-- Right -->
			<div>
			<a href="https://www.facebook.com/" class="me-4 text-reset">
				<i class="fab fa-facebook-f"></i>
			</a>
			<a href="https://www.twitter.com/" class="me-4 text-reset">
				<i class="fab fa-twitter"></i>
			</a>
			<a href="https://www.instagram.com/" class="me-4 text-reset">
				<i class="fab fa-instagram"></i>
			</a>
			<a href="https://www.youtube.com/" class="me-4 text-reset">
				<i class="fab fa-youtube"></i>
			</a>
			</div>
			<!-- Right -->
		</section>
		<!-- Section: Social media -->

		<!-- Section: Links  -->
		<section class="">
			<div class="container text-center text-md-start mt-5">
			<!-- Grid row -->
			<div class="row mt-3">
				<!-- Grid column -->
				<div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
				<!-- Content -->
				<h6 class="text-uppercase fw-bold mb-4" style="font-family:Montserrat">
					<i class="fas fa-gem me-3"></i>SMP Islam Percobaan
				</h6>
				<p>
					SMP Islam Percobaan adalah sebuah SMP Unggulan yang berbasis Islam yang berlokasi di Kota Malang
				</p>
				</div>
				<!-- Grid column -->

				<!-- Grid column -->
				<div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
				<!-- Links -->
				<h6 class="text-uppercase fw-bold mb-4">
					Aplikasi Sekolah
				</h6>
				<p>
					<a href="#!" class="text-reset">SSPDB (Sistem Seleksi Peserta Didik baru)</a>
				</p>
				<p>
					<a href="#!" class="text-reset">Perpustakan Online</a>
				</p>
				<p>
					<a href="#!" class="text-reset">E-Class</a>
				</p>
				<p>
					<a href="#!" class="text-reset">Pembayaran Online</a>
				</p>
				</div>
				<!-- Grid column -->

				<!-- Grid column -->
				<div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
				<!-- Links -->
				<h6 class="text-uppercase fw-bold mb-4" style="font-family:Montserrat">
					LINK TERKAIT
				</h6>
				<p>
					<a href="https://kemenag.go.id/" class="text-reset">Kementerian Agama RI</a>
				</p>
				<p>
					<a href="https://jatim.kemenag.go.id/" class="text-reset">Kementerian Agama Jawa Timur</a>
				</p>
				<p>
					<a href="https://www.kemdikbud.go.id/main/" class="text-reset">Kemdikbud RI</a>
				</p>
				<p>
					<a href="https://dindik.jatimprov.go.id/" class="text-reset">Kemdikbud Jawa Timur</a>
				</p>
				</div>
				<!-- Grid column -->

				<!-- Grid column -->
				<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
				<!-- Links -->
				<h6 class="text-uppercase fw-bold mb-4">
					Contact
				</h6>
				<p><i class="fas fa-home me-3"></i> Malang, Jawa Timur, Indonesia</p>
				<p>
					<i class="fas fa-envelope me-3"></i>
					kelompokpdwhahahihi@mail.com
				</p>
				<p><i class="fas fa-phone me-3"></i> + 62 859 4047 4523</p>
				</div>
				<!-- Grid column -->
			</div>
			<!-- Grid row -->
			</div>
		</section>
		<!-- Section: Links  -->

		<!-- Copyright -->
		<div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
			Website ini dibuat oleh Kelompok G PDW 2022
		</div>
		<!-- Copyright -->
	</footer>
		<!-- Footer -->	

	<!-- Jquery dan Bootsrap JS -->
	<script src="<?= base_url('js/jquery.min.js') ?>"></script>
	<script src="<?= base_url('js/bootstrap.min.js') ?>"></script>

</body>
</html>