<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SMP Islam Percobaan</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css') ?>" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,300,700' rel='stylesheet' type='text/css'>
	<script src="https://kit.fontawesome.com/b5bf755f1d.js" crossorigin="anonymous"></script>
</head>

<body id="page-top">
	<div class="header py-4" style="background-color: #273755;">
		<div class="container">
			<a href="https://www.facebook.com/" class="fa fa-facebook" style="color: #FFFFFF; position"></a>
			<a href="https://www.twitter.com/" class="px-4 fa fa-twitter" style="color: #1D9BF0;"></a>
			<a href="https://www.instagram.com/" class="fa fa-instagram" style="color: #8A3AB9;"></a>
			<a href="https://www.youtube.com/" class="px-4 fa fa-youtube" style="color: #FF0000;"></a>
		</div>
	</div>
	<nav class="navbar navbar-expand-sm sticky-top py-4 navbar-dark" style="background-color: #8AABCA; font-family:Montserrat;" id="mainNav;">
		<div class="container">
			<h2>
				<a class="navbar-brand" href="<?= base_url() ?>">
					<img src="https://iili.io/X4hfwb.png" height="30">
					SMP Islam Percobaan
				</a>
			</h2>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      			<span class="navbar-toggler-icon"></span>
    		</button>
			<div class="collapse navbar-collapse active" aria-current="page" style="color: #273755;" id="navbarNav">
				<ul class="navbar-nav me-auto mb-2 mb-lg-0">
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url() ?>">Beranda</a>
					</li>
					<li class="nav-item dropdown">
          				<a class="nav-link dropdown-toggle" aria-current="page" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            				Profil Sekolah
          				</a>
          				<ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink" style="background-color:#273755;">
						  	<li><a class="dropdown-item" href="sejarah">Sejarah Sekolah</a></li>
						 	<li><a class="dropdown-item" href="sambutan">Sambutan Kepala Sekolah</a></li>
							<li><a class="dropdown-item" href="guru">Jajaran Guru-Guru</a></li>
          				</ul>
					</li>
					<li class="nav-item dropdown">
          				<a class="nav-link dropdown-toggle active" aria-current="page" style="color: #273755;" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            				Program Sekolah
          				</a>
          				<ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDropdownMenuLink" style="background-color:#273755;">
            				<li><a class="dropdown-item" href="kurikulum">Kurikulum Sekolah</a></li>
            				<li><a class="dropdown-item" href="agama">Program Keagamaan</a></li>
							<li><a class="dropdown-item" href="ekstra">Kegiatan Ekstrakulikuler</a></li>
          				</ul>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url('ppdb') ?>">PPDB</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

    <br><br>
    <header class="jumbotron jumbotron-fluid">
		<div class="container">
			<div class="row">
				<div class="col-md-12 py-4" style="font-family:Montserrat;">
					<h1 class="h1">Kegiatan Ekstrakulikuler</h1>
                    <br><br>
				</div>
			</div>
		</div>
	</header>

    <div class="container" style="font-family:Montserrat;">
        <h3>Program pendidikan Sekolah Menengah Pertama Islam Percobaan ditunjang dengan berbagai program kegiatan Ekstra Kurikuler yang berupa:</h3>
	</div>
    <br><br>

    <div class="container" style="font-family:Montserrat;">
        <h4>
            1. Seni Rebana <br>
            2. Seni Musik <br>
            3. Palang Merah Remaja <br>
            4. Pramuka <br>
            5. UKS <br>
            6. Seni Baca Al-Qur’an <br>
            7. Drum Band <br>
            8. Mading / Jurnalistik <br>
            9. Seni Bela Diri Pagar Nusa <br>
            10. Bulutangkis <br>
            11. Volly <br>
            12. Basket <br>
            13. Futsal <br>
            14. English Club <br>
            15. PIK Remaja <br>
        </h4>
	</div>
    <br><br><br>


</body>